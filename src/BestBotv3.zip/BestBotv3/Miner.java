package BestBotv3;

import battlecode.common.*;

import java.util.ArrayList;
import java.util.Map;

/*
 * WHAT DOES THE MINER DO (in order)
 * update stuff
 * build 1 school when summoned by HQ
 * IF SCHOOL IN RADIUS THEN RUN AWAY!!!!!!!!!!!
 * try deposit soup
 * try mine soup
 * move
 */

/*
 * STATE-MANAGEMENT - think of each bot being in a certain 'state' at any point in time.
 *   Use takeTurn() to define the states, and then use methods to define the behavior in that state.
 *
 * MINER STATE(s) in order of priority/precedence
  0.update stuff (also crawls chain on turnCount==1)
  1.INITIALIZATION (turnCount == 1)
  2.Don't get drowned.
  3.if you can see all tiles in a 5x5 around soup or a refinery:
    A. if it's hq, presence of landscapers also define accessibility.
    B. if it's not accessible, remove it from locations arraylist.
  3.if <= 2 squared away from a landscaper, run away.
  4.if there are no refineries, build one.
  5.if there are no amazons, build one in suitable location.
  6. if there is an amazon and no design school, build a design school in suitable location.
  7.if at soup limit:
    A. if there is a refinery:
      a. if it's not too far away, go to it.
      b. if it's too far away and there's more than 50 soup:
        1. build one if you can.
      c. if it's too far away and there's less than 50 soup:
        1. go to it anyway. (don't need miners sitting around, waiting for passive soup income)
    B. if there is no refinery, build it.
  8.if at > 80% soup limit, try to deposit in all directions.
  9.if
  *
1/21/2020 I'll finish this later. -jm.

 */

public class Miner extends Unit {

    int numDesignSchools = 0;
    int distanceToMakeRefinery = 50;
    boolean IBroadcastedWaterLoc = false; //Use for only sending 1 water loc per miner(We lose from overspending)

    // ALL "...Locations" ArrayList<MapLocation> ARE IN Unit.java!!!!!!!!!!!!!!!!!!!!


    public Miner(RobotController r) {
        super(r);
    }

    boolean hqRemovedFromRefineryLocations = false;

    // array and not an arraylist!
    MapLocation[] recentlyVisitedLocations = new MapLocation[7];


    public void takeTurn() throws GameActionException {
        super.takeTurn();

        comms.updateBuildingLocations();
        comms.updateSoupLocations(soupLocations);
        recentlyVisitedLocations[turnCount%7] = myLoc;

        if (turnCount == 1) {
            // System.out.println("adding hq to refineries");
            refineryLocations.add(hqLoc);   // since hq is technically a refinery
        }

        // if (near water()) { find higherground }



        if (soupLocations.size() > 0) {
            checkIfSoupGone(findClosestSoup());
        }
//        if (hqLoc == null){
////            comms.broadcastBuildingCreation(RobotType.HQ, hqLoc);
//            // System.out.println("Hq didnt broadcast its location well");
//        } else {
//            // System.out.println("HQ has been broadcasted and I recieved. Its at " + hqLoc);
//        }


        // TODO: 1/21/2020 How can we make the miners sense water anywhere in their field of vision? -matt
        // TODO: Why was this commented out? Commenting makes them blind to water entirely -cam
        if (!IBroadcastedWaterLoc) {
            for (Direction dir : Util.directions) {
                if (rc.canSenseLocation(myLoc.add(dir))) {
                    if (rc.senseFlooding(myLoc.add(dir))) {
                        comms.broadcastWaterLocation(myLoc.add(dir));
                        IBroadcastedWaterLoc = true;
                    }
                }
            }
        }

        if (refineryLocations.size() > 0) {
            checkIfRefineryGone(findClosestRefinery());
        }

        // Build 1 amazon, then build school.
        if (amazonLocations.size() == 0 && rc.getTeamSoup() >= RobotType.FULFILLMENT_CENTER.cost + 5) {
            if (myLoc.distanceSquaredTo(hqLoc) > 2) {
                // System.out.println("Trybuild amazon");
                if (tryBuild(RobotType.FULFILLMENT_CENTER, myLoc.directionTo(hqLoc).opposite())) {
                    comms.broadcastBuildingCreation(RobotType.FULFILLMENT_CENTER, myLoc.add(myLoc.directionTo(hqLoc).opposite()));
                }
            }
        } else if (designSchoolLocations.size() == 0){
            if (rc.getTeamSoup() >= RobotType.DESIGN_SCHOOL.cost && myLoc.distanceSquaredTo(hqLoc) < 9) {
                // System.out.println("No design schools yet, gotta build one");
                if (tryBuild(RobotType.DESIGN_SCHOOL, myLoc.directionTo(hqLoc).opposite())) {
                    // System.out.println("built school");
                    comms.broadcastBuildingCreation(RobotType.DESIGN_SCHOOL, myLoc.add(myLoc.directionTo(hqLoc).opposite()));
                }
            } else {
                // System.out.println("There are no design schools, but we dont have enough money to make one");
            }
        } else {
            // System.out.println("There are design schools");
            boolean landscapersNearby = false;
            RobotInfo[] nearbyTeammates = rc.senseNearbyRobots(RobotType.MINER.sensorRadiusSquared, rc.getTeam());
            if (nearbyTeammates.length > 0) {
                for (RobotInfo bot : nearbyTeammates) {
                    if (bot.type.equals(RobotType.LANDSCAPER)) {
                        landscapersNearby = true;
                        break;
                    }
                }
            }

            if (landscapersNearby) {
                if (!hqRemovedFromRefineryLocations) {
                    // System.out.println("remove hq from refineries");
                    refineryLocations.remove(hqLoc);
                    hqRemovedFromRefineryLocations = true;
                }
                // need to build refinery ASAP
                if (refineryLocations.size() == 0) {
                    // System.out.println("need to build refinery asap");
                    buildRefineryIfAppropriate();
                } else if (myLoc.distanceSquaredTo(findClosestRefinery()) > distanceToMakeRefinery) {
                    for (Direction dir: Util.directions) {
                        if (!dir.equals(myLoc.directionTo(hqLoc))
                                && !dir.equals(myLoc.directionTo(hqLoc).rotateLeft())
                                && !dir.equals(myLoc.directionTo(hqLoc).rotateRight()) ) {
                            if (rc.getTeamSoup() >= RobotType.REFINERY.cost + 5 && tryBuild(RobotType.REFINERY, dir)) {
                                comms.broadcastBuildingCreation(RobotType.REFINERY, myLoc.add(dir));
                            }
                        }
                    }
                }

                // TODO: 1/20/2020 gotta try and make it move away from HQ
                if (myLoc.distanceSquaredTo(hqLoc) < 6) {
                    runAwayyyyyy();
                }
            }
        }


        // TODO: 1/20/2020 somehow trying to deposit and refine in all directions slows down mining when miner is next to hq

        if (rc.getSoupCarrying() >= RobotType.MINER.soupLimit-7) {
            // Better to deposit soup while you can
            for (Direction dir : Util.directions) {
                if (rc.canDepositSoup(dir)) {
                    rc.depositSoup(dir, rc.getSoupCarrying());
                    // System.out.println("Deposited soup into refinery");
                }
            }
        }
            // then, try to mine soup in all directions
        for (Direction dir : Util.directions) {
            if (tryMine(dir)) {
                // System.out.println("I mined soup! " + rc.getSoupCarrying());
                MapLocation soupLoc = myLoc.add(dir);
                if (!soupLocations.contains(soupLoc)) {
                    comms.broadcastSoupLocation(soupLoc);
                }
            }
        }


        // if closest refinery is far away, build a refinery.

        // MOVEMENT

                // if at soup limit, go to nearest refinery
                //      if there is a design school, hq is no longer part of the nearest refineries.
                // if there are soupLocations, go to nearest soup
                // else, move away from other miners

        if (rc.getSoupCarrying() == RobotType.MINER.soupLimit) {
            // System.out.println("I'm full of soup, refineTime");

            // TODO: 1/20/2020 need to sit still when there isn't enough soup
            buildRefineryIfAppropriate();

            //find closest refinery (including hq, should change that tho since HQ will become unreachable)
            if (refineryLocations.size() > 0) {
                MapLocation closestRefineryLoc = findClosestRefinery();
                minerGoTo(closestRefineryLoc);
                rc.setIndicatorLine(rc.getLocation(), closestRefineryLoc, 255, 0, 255);
            }
            // else, just sit there?
        }
        else {
            if (soupLocations.size() > 0) {
                minerGoToNearestSoup();
            } else {
                searchForSoup();
            }
        }
    }

    // ----------------------------------------------- METHODS SECTION ---------------------------------------------- \\

    public void minerGoToNearestSoup() throws GameActionException {

        MapLocation nearestSoupLoc = findClosestSoup();

        // TODO: 1/20/2020 make miner sense soup, and add to soupLocations if said sensed soup is accessible
        // if a tile adjacent to soup is not flooded, it is accessible
        // if we can see around soupLoc, check if accessible
//        if (myLoc.distanceSquaredTo(nearestSoupLoc) < 20) {
//            while(!isSoupAccessible(nearestSoupLoc)) {
//                nearestSoupLoc = findClosestSoup();
//            }
//        }
        // System.out.println("I'm moving to soupLocation " + nearestSoupLoc);

        rc.setIndicatorLine(rc.getLocation(), nearestSoupLoc, 255, 0, 255);
        minerGoTo(nearestSoupLoc);

    }

    public void searchForSoup() throws GameActionException {
        // System.out.println("I'm searching for soup, moving away from other miners");
        RobotInfo[] robots = rc.senseNearbyRobots(RobotType.MINER.sensorRadiusSquared, rc.getTeam());
        MapLocation nextPlace = myLoc;
        for (RobotInfo robot : robots) {
            if (robot.type == RobotType.MINER) {
                nextPlace = nextPlace.add(myLoc.directionTo(robot.location).opposite());
            }
        }
        if (robots.length == 0) {
            nextPlace.add(Util.randomDirection());
        }
        // System.out.println("Trying to go: " + rc.getLocation().directionTo(nextPlace));
        if (nextPlace != rc.getLocation()) {
            minerGoTo(rc.getLocation().directionTo(nextPlace));

        } else {
            minerGoTo(Util.randomDirection());
        }
    }

    // builds a refinery if there are none or if we are far enough away from the closest one (which includes hq)
    // if near hq, don't build in the direction of hq
    public void buildRefineryIfAppropriate() throws GameActionException {

        // if near hq, don't build in the direction of hq
        if ((myLoc.distanceSquaredTo(hqLoc) < 8) && refineryLocations.size() < 2) {
            for (Direction dir: Util.directions) {
                if (!dir.equals(myLoc.directionTo(hqLoc))
                        && !dir.equals(myLoc.directionTo(hqLoc).rotateLeft())
                        && !dir.equals(myLoc.directionTo(hqLoc).rotateRight()) ) {
                    // System.out.println("trybuild refinery away from hq");
                    if (tryBuild(RobotType.REFINERY, dir)) {
                        comms.broadcastBuildingCreation(RobotType.REFINERY, myLoc.add(dir));
                        break;
                    }
                }
            }
        }
        // if no refineries (i.e. there is a school and we can't use hq) build one asap
        if (refineryLocations.size() == 0) {
            for (Direction dir : Util.directions) {
                // System.out.println("trybuild refinery");
                if (tryBuild(RobotType.REFINERY, dir)) {
                    comms.broadcastBuildingCreation(RobotType.REFINERY, myLoc.add(dir));
                    break;
                }
            }
        } else { // findClosestRefinery REQUIRES that there be at least 1 refinery
            MapLocation closestRefinery = findClosestRefinery();
            // if further than 10, tries to build in all directions. breaks loop when it can.
            if (myLoc.distanceSquaredTo(closestRefinery) > 20) {
                for (Direction dir : Util.directions) {
                    // System.out.println("trybuild refinery, far away");
                    if (tryBuild(RobotType.REFINERY, dir)) {
                        comms.broadcastBuildingCreation(RobotType.REFINERY, myLoc.add(dir));
                        break;
                    }
                }
            }
        }
    }

    // MAKE SURE SOUPLOCATIONS.SIZE > 0 WHEN USING THIS METHOD
    public MapLocation findClosestSoup() throws GameActionException {
        MapLocation nearestSoupLoc = soupLocations.get(0);

        // Find Closest Soup Location if theres more than 1
        if (soupLocations.size() > 0) { // This might be fixed because intelij thinks that its always greater than 0, not really sure. - Matt 1/21
            for (MapLocation loc : soupLocations) {
                if (myLoc.distanceSquaredTo(loc) < myLoc.distanceSquaredTo(nearestSoupLoc)) {
                    nearestSoupLoc = loc;
                }
            }
        }
        return nearestSoupLoc;
    }

    // MAKE SURE REFINERYLOCATIONS.SIZE > 0 WHEN USING THIS METHOD
    public MapLocation findClosestRefinery() throws GameActionException {
        MapLocation closestRefineryLoc = refineryLocations.get(0);

        //Find Closest Refinery if there's more than 1
        if (refineryLocations.size() > 0) {
            for (MapLocation refinery : refineryLocations) {
                if (myLoc.distanceSquaredTo(refinery) < myLoc.distanceSquaredTo(closestRefineryLoc)) {
                    closestRefineryLoc = refinery;
                }
            }
        }
        return closestRefineryLoc;
    }


    /**
     * Attempts to mine soup in a given direction.
     *
     * @param dir The intended direction of mining
     * @return true if a move was performed
     * @throws GameActionException
     */
    boolean tryMine(Direction dir) throws GameActionException {
        if (rc.isReady() && rc.canMineSoup(dir)) {
            rc.mineSoup(dir);
            return true;
        } else return false;
    }

    /**
     * Attempts to refine soup in a given direction.
     *
     * @param dir The intended direction of refining
     * @return true if a move was performed
     * @throws GameActionException
     */
    boolean tryRefine(Direction dir) throws GameActionException {
        if (rc.isReady() && rc.canDepositSoup(dir)) {
            rc.depositSoup(dir, rc.getSoupCarrying());
            return true;
        } else return false;
    }

    void checkIfSoupGone(MapLocation loc) throws GameActionException {
        if (soupLocations.size() > 0) {
            // System.out.println("check soup" + loc);
//            MapLocation targetSoupLoc = soupLocations.get(0);
            if (rc.canSenseLocation(loc)
                    && rc.senseSoup(loc) == 0) {
                // System.out.println("soup at " + loc + "is gone");
                soupLocations.remove(loc);
            } /*else {
                if (myLoc.distanceSquaredTo(loc) < 20 *//*&& !isSoupAccessible(loc)*//*) {
                    // System.out.println("soup at " + loc + "is gone");
                    soupLocations.remove(loc);
                }
            }*/
        }
    }
    void checkIfRefineryGone(MapLocation loc) throws GameActionException {
        if (refineryLocations.size() > 0) {
//            MapLocation targetSoupLoc = soupLocations.get(0);
            if (rc.canSenseLocation(loc)
                    && (!rc.senseRobotAtLocation(loc).type.equals(RobotType.REFINERY)
                    && !rc.senseRobotAtLocation(loc).type.equals(RobotType.HQ))) {
                // System.out.println("refinery at " + loc + "is gone");
                refineryLocations.remove(loc);
            }
        }
    }

    // fuzzy nav, except it won't go to a place it has visited in the last ten rounds
    boolean minerGoTo(Direction dir) throws GameActionException {

        // if dir is north, order would be N, NW, NE, W, E, SW, SE, S
        Direction[] fuzzyNavDirectionsInOrder = { dir, dir.rotateLeft(), dir.rotateRight(),
                dir.rotateLeft().rotateLeft(), dir.rotateRight().rotateRight(),
                dir.rotateLeft().rotateLeft().rotateLeft(), dir.rotateRight().rotateRight().rotateRight(),
                dir.opposite(),
        };

        MapLocation moveTowardLocation = myLoc;
        boolean shouldIMoveThere = true;
        Direction moveToward = fuzzyNavDirectionsInOrder[0];
        for (int i = 0; i < 8; i ++) {
            moveToward = fuzzyNavDirectionsInOrder[i];
            moveTowardLocation = myLoc.add(moveToward);

            for (int j = 0; j < recentlyVisitedLocations.length; j++) {
                if (moveTowardLocation.equals(recentlyVisitedLocations[j])) {
                    shouldIMoveThere = false;
                    break;
                }
            }

            // System.out.println("move " + fuzzyNavDirectionsInOrder[i] + "? " + shouldIMoveThere);

            if (shouldIMoveThere) {
                if (nav.tryMove(moveToward)) {
                    return true;
                }
            }
        }
//
//        for (Direction d : toTry){
//            if(tryMove(d))
//                return true;
//        }
        return false;
    }

    // navigate towards a particular location
    boolean minerGoTo(MapLocation destination) throws GameActionException {
        return minerGoTo(rc.getLocation().directionTo(destination));
    }
    
    

    // basically, goes in the direction of the center of the map
    void runAwayyyyyy() throws GameActionException {
        // System.out.println("Run awayyyyyyyy");

        if (hqLoc.x < (rc.getMapWidth() / 2) && hqLoc.y > (rc.getMapHeight() / 2)) { // top left
            minerGoTo(new MapLocation(myLoc.x + 4, myLoc.y - 4));
        } else if (hqLoc.x > (rc.getMapWidth() / 2) && hqLoc.y > (rc.getMapHeight() / 2)) { // top right
            minerGoTo(new MapLocation(myLoc.x + 4, myLoc.y - 4));
        } else if (hqLoc.x < (rc.getMapWidth() / 2) && hqLoc.y < (rc.getMapHeight() / 2)) { // bottom left
            minerGoTo(new MapLocation(myLoc.x + 4, myLoc.y - 4));
        } else if (hqLoc.x > (rc.getMapWidth() / 2) && hqLoc.y < (rc.getMapHeight() / 2)) { // bottom right
            minerGoTo(new MapLocation(myLoc.x + 4, myLoc.y - 4));
        } // else.. idk?!?!?
    }
}
