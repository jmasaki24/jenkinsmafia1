package BestBotv3;

import battlecode.common.RobotController;

public class Vaporator extends Building {
    public Vaporator(RobotController r) {
        super(r);
    }
}
