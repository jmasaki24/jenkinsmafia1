package BestBotv3;

import battlecode.common.RobotController;

public class Refinery extends Building {
    public Refinery(RobotController r) {
        super(r);
    }
}
