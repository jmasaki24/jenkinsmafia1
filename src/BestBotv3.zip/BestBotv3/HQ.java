package BestBotv3;

import battlecode.common.*;

import java.rmi.MarshalledObject;
import java.util.Map;
/*
 * FIRST FEW ROUNDS STRATEGY
 * Build 4 miners, start refining soup in HQ
 * Build Amazon, drone. Drone is on standby (hover near HQ, wait for enemy units)
 * Build design school
 * Build refinery (if there isn’t already one)
 * build 2 landscapers
 */
public class HQ extends Shooter {
    public int numMiners = 0;

    // why is this static? idk. might be helpful later. -jm
    public static final int MINER_LIMIT = 4;

    public HQ(RobotController r) throws GameActionException {
        super(r);
        comms.sendHqLoc(rc.getLocation());
    }


    public void takeTurn() throws GameActionException {
        super.takeTurn();
        int numSoupNearby = 0;
        // on first turn, sendHqLoc, send nearbySoupLocations,
        if (turnCount == 1) {
            comms.sendHqLoc(rc.getLocation());
            MapLocation[] nearbySoupLocations = rc.senseNearbySoup();
            if (nearbySoupLocations.length > 0) {
                for (MapLocation nearbySoup : nearbySoupLocations) {
                    System.out.println("hq sees soup " + nearbySoup);
                    // TODO: 1/19/2020 if the soup is surrounded by water, miner will be fucked
                    if (numSoupNearby < 20) { // don't want to spend all the soup broadcasting locs
                        if (myLoc.distanceSquaredTo(nearbySoup) < 32 && isSoupAccessible(nearbySoup)) {
                            comms.broadcastSoupLocation(nearbySoup);
                            numSoupNearby++;
                        } else {
                            comms.broadcastSoupLocation(nearbySoup);
                            numSoupNearby++;
                        }
                    }
                }
            }
        }

        // wait until 30th turn to send nearby water locations cuz who knows how much soup we'll have
        if (turnCount == 30) {
            broadcastNearbyWaterLocations();
        }

        //Every 3 turns repeat messages. why >3? see method
        if (turnCount > 3 && turnCount % 3 == 2) {
            comms.jamEnemyComms();
        }

        if (numMiners < MINER_LIMIT) {
            for (Direction dir : Util.directions)
                if (tryBuild(RobotType.MINER, dir)) {
                    numMiners++;
                }
        } else if (comms.amazonMade()) { // WHAT IS GOING ON HERE??? 1.19.2020 -jm
//          for (Direction dir : Util.directions) {
//              if (tryBuild(RobotType.MINER, dir)) {
//                  numMiners++;
//              }
//          }
        }

        //Request a school next to base
        boolean seeDesignSchool = false;
        RobotInfo[] robots = rc.senseNearbyRobots(RobotType.HQ.sensorRadiusSquared, rc.getTeam());
        for (RobotInfo robot : robots) {
            if (robot.type == RobotType.DESIGN_SCHOOL) {
                seeDesignSchool = true;
            } else if ((robot.type == RobotType.MINER || robot.type == RobotType.LANDSCAPER) && robot.getTeam() == rc.getTeam().opponent()){
                // I am intentionally leaving out the team part of it just to test if the drones will pick up our own miners or not
                comms.broadcastAttackerInfo(robot.ID, myLoc.directionTo(robot.location));
            }
        }


        if (!seeDesignSchool) {
            if (rc.getTeamSoup() > RobotType.DESIGN_SCHOOL.cost + RobotType.MINER.cost) {
                tryBuild(RobotType.MINER, Direction.SOUTHWEST);
            }
        }
//        if (seeDesignSchool && rc.getRoundNum() > 300){
//            for (Direction dir: Util.directions){
//                tryBuild(RobotType.MINER,Util.randomDirection());
//            }
//        }
    }

    // go from top row to bottom row, left to right
    void broadcastNearbyWaterLocations() throws GameActionException {
        int checkThisX = myLoc.x;
        int checkThisY = myLoc.y;
        MapLocation checkThisLoc = myLoc;


        // FIRST ROW
        checkThisX = myLoc.x - 3;
        checkThisY = myLoc.y + 6;

    }

}
